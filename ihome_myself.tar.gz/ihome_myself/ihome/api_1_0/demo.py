# coding:utf-8
from PIL.EpsImagePlugin import field

from ihome.models import Goods
from . import api, api_demo
from flask_restful import Resource, Api, fields, abort, marshal, marshal_with
from ihome import db, models
# import logging
from flask import current_app, request


# api = Api(api)

# @api.route("/hello")
# def hello():
#     return {"Hello": "World"}

class HelloResource(Resource):
    def get(self):
        return {"Hello": "World"}


api_demo.add_resource(HelloResource, "/hello/")

# @api.route("/index", methods=["POST", "GET"])
# def index():
#     #print("hello")
#     # logging.error()   # 记录错误信息
#     # logging.warn()   # 警告
#     # logging.info()   # 信息
#     # logging.debug()   # 调试
#     current_app.logger.error("error info")
#     current_app.logger.warn("warn info")
#     current_app.logger.info("info info")
#     current_app.logger.debug("debug info")
#     return "index page"
#
#
# # logging.basicConfig(level=logging.ERROR)
#
# from flask_restful import Resource, Api
#
# # app = Flask(__name__)
# # api = Api(app)
# api.route("/index", methods=["POST", "GET"])
#
#
# class HelloWorld(Resource):
#     def get(self):
#         return {'hello': 'world'}
#
# api.add_resource(HelloWorld, '/')


goods_fields = {
    "g_name": fields.String,
    "g_price": fields.Float
}
single_goods_fieds = {
    "data": fields.Nested(goods_fields),
    "status": fields.Integer,
    "msg": fields.String,
}

multi_goods_fieds = {
    "data": fields.Nested(goods_fields),
    "status": fields.Integer,
    "msg": fields.String,
}


class GoodsListResource(Resource):
    # @marshal_with(single_goods_fieds)
    def get(self):
        goods_list = Goods.query.all()
        data = {
            "status": 200,  # 必须与single_goods_fieds保持一致
            "msg": "ok",
            "data": goods_list
        }
        return marshal(data, multi_goods_fieds)
    
    def post(self):
        g_name = request.form.get("g_name")
        g_price = request.form.get("g_price")
        print(g_name, g_price)
        goods = Goods()
        goods.g_name = g_name
        goods.g_price = g_price

        if not goods.save:
            abort(400)
        ret = {
            "status": 200,
            "msg": "ok",
            "data": marshal(goods, goods_fields)
        }
        return ret

api_demo.add_resource(GoodsListResource, "/goods/")