# coding:utf-8
from datetime import datetime
import os
from . import api
from flask import session
from ihome.utils.commons import login_required
from flask import g, current_app, jsonify, request
from ihome.utils.response_code import RET
from ihome.utils.image_storage import storage
from ihome.models import User
from ihome import db, constants


@api.route("/users/avatar", methods=["POST"])
@login_required
def set_user_avatar():
    """设置用户的头像
    参数： 图片(多媒体表单格式)  用户id (g.user_id)
    """
    # 装饰器的代码中已经将user_id保存到g对象中，所以视图中可以直接读取
    user_id = g.user_id

    # 获取图片
    image_file = request.files.get("avatar")

    if image_file is None:
        return jsonify(errno=RET.PARAMERR, errmsg="未上传图片")

    image_data = image_file.read()

    # 调用七牛上传图片, 返回文件名
    try:
        user = User.query.filter_by(id=user_id).first()
        # file_name = storage(image_data)
        # user.update({'portrait': image_data})
        # # user = User(portrait=image_data)
        user.portrait = image_data
        db.session.add(user)
        db.session.commit()

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="保存图片信息失败")
        # file_name = str(user_id) + "_" + datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        # print(file_name)
        # current_app.logger.error(e)
        # return jsonify(errno=RET.THIRDERR, errmsg="上传图片失败")

    # 保存文件名到数据库中
    # try:
    #     User.query.filter_by(id=user_id).update({"avatar_url": file_name})
    #     db.session.commit()
    # except Exception as e:
    #     db.session.rollback()
    #     current_app.logger.error(e)
    #     return jsonify(errno=RET.DBERR, errmsg="保存图片信息失败")

    avatar_url =  constants.QINIU_URL_DOMAIN
    # 保存成功返回
    return jsonify(errno=RET.OK, errmsg="保存成功", data={"avatar_url": avatar_url})



@api.route("/users/image", methods=["GET","POST"])
# @login_required
def get_image():
    # user_image_url_part = request.path
    # user_image_url_part = user_image_url_part.split("/")[-1]
    user_id = session.get("user_id")
    # user_id = g.user_id
    print(user_id*1000)
    image_file = User.query.filter_by(id=user_id).first()
    print(image_file, "____________")
    return  image_file, 200



