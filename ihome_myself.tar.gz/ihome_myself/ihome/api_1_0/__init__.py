# coding:utf-8

from flask import Blueprint

from flask_restful import Resource, Api
# 创建蓝图对象
# from
api = Blueprint("api_1_0", __name__)
# from ihome.api_1_0.demo import aapipi
api_demo = Api(api)

# 导入蓝图的视图
from . import verify_code, passport, profile, houses, demo


from flask_restful import Resource, Api

# app = Flask(__name__)
# api = Api(app)
# api.route("/index", methods=["POST", "GET"])