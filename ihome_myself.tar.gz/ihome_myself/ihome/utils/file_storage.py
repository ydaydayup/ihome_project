# encoding: utf8

import random, string
from flask import current_app
from ihome import db
from flask import request
from ihome.constants import File__URL_DOMAIN
from . import file_data
# from commons import ReConverter
# file_data.url_map.converters["re"] = ReConverter
from commons import login_required
url_suffix = "".join(random.sample(string.ascii_letters+string.digits,10))

def file_save(data):
    from ihome.models import Photo
    url = File__URL_DOMAIN + url_suffix
    file = Photo(file_data=data, url=url)
    try:
        db.session.add(file)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(e)
        raise Exception(e)
    return url


# @api.route("/sms_codes/<re(r'1[34578]\d{9}'):mobile>")
# @file_data.route("/file/<re(r'.*'):url>", methods=["POST", "GET"])
@file_data.route("/file/<re('.*'):url>", methods=["POST", "GET"])
def re_file_data(url):
    """
    1. 我在配置路由的时候出错了（127,不是172）
    2. 用自定义的动态路由要在函数中传递参数
    3. 大图片无法保存，问题暂不解决
    :param url:
    :return:
    """
    from ihome.models import Photo
    url = request.url
    photo = Photo.query.filter_by(url=url).first()
    data = photo.file_data
    return data


