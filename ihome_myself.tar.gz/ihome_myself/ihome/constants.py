# coding:utf-8


# 图片验证码的redis有效期, 单位：秒
IMAGE_CODE_REDIS_EXPIRES = 18000

# 短信验证码的redis有效期, 单位：秒
SMS_CODE_REDIS_EXPIRES = 300

# 发送短信验证码的间隔, 单位：秒
SEND_SMS_CODE_INTERVAL = 60

# 登录错误尝试次数
LOGIN_ERROR_MAX_TIMES = 5

# 登录错误限制的时间, 单位：秒
LOGIN_ERROR_FORBID_TIME = 600

# 七牛的域名
# QINIU_URL_DOMAIN = "http://o91qujnqh.bkt.clouddn.com/"
QINIU_URL_DOMAIN = "http://127.0.0.1:5000/api/v1.0/users/image"
File__URL_DOMAIN = "http://127.0.0.1:5000/utils/v1.0/file/"
HOUSE_LIST_PAGE_CAPACITY = 1

# 城区信息的缓存时间, 单位：秒
AREA_INFO_REDIS_CACHE_EXPIRES = 7200